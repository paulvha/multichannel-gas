/* Multi channel gas sensor user program
 *  
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 * 
 * Initial release September 2017.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */

#include "gass.h"

// detailed /debug information
int DEBUG = 0;
int DETAILS =0; 

int loop_seconds = 5;		// time in seconds to wait in between show

int slave_address_base= 0xff; // current slave address
int use_I2C_add = 0xff;		// as provided with -A option

int warm_up_time = 0;		// warm_up_time in minutes

int		NoColor = 0;		// disables color output (if set)

/*********************************************************************
** Function name:           init_I2c_add
** Descriptions:            Obtain current I2C address to use
**
** Either detect current address by searching OR use the address 
** provided on the command line ( -A option)
** return -1 = error
********************************************************************/

int init_I2c_add()
{
	if (use_I2C_add != 0xff) 
	{
		// set BCM2835 slaveaddress
		bcm2835_i2c_setSlaveAddress(use_I2C_add);
		
		return(use_I2C_add);
	}
	
	return (detect_base_address());
}

/*********************************************************************
** Function name:           hw_init
** Descriptions:            setup hardware 
**
** set the BCM2835 for I2c communication 
** return 0 = ok, -1 = error
********************************************************************/
int hw_init() 
{
     if (!bcm2835_init()) {
        p_printf(RED,"Can't init bcm2835!\n");
        exit(1);
    }

    // will select I2C channel 0 or 1 depending on board reversion.
    if (!bcm2835_i2c_begin()) {
        p_printf(RED,"Can't setup i2c pin!\n");
        
        // release BCM2835 library
		bcm2835_close();
        return(-1);
    }
    
    /* set BSC speed to 100Khz*/
    bcm2835_i2c_setClockDivider(BCM2835_I2C_CLOCK_DIVIDER_2500);
	
	// obtain current slave address
	if ((slave_address_base = init_I2c_add()) < 1)
	{
        p_printf(RED,"Can't obtain slave address!\n");
        
        // release BCM2835 library
		close_out(1);		
	}
	
	if (DEBUG) p_printf(GREEN,"Detected sensor on address 0x%x\n",slave_address_base);
	
	/* get version of current gas sensor*/
	if (getVersion() < 1)
	{
        p_printf(RED,"Can't obtain version!\n");
        
        // release BCM2835 library
		close_out(1);		
	}
	
	return(0);
}

/* end the program correctly */
void close_out(int end)
{
    
    // reset pins
	bcm2835_i2c_end();	
	
    // release BCM2835 library
    bcm2835_close();

    // exit with return code
    exit(end);
}

/**********************************************************************
** Function name:           p_printf
** Descriptions:            display messages
**
** @param format : Message to display & optional arguments (as printf)
** @param level :  RED, GREEN, YELLOW, BLUE  or WHITE
** 
**  if NoColor was set, output is always WHITE.
***********************************************************************/

void p_printf (int level, char *format, ...)
{
    char	*col;
    int		coll=level;
    va_list arg;
    
    //allocate memory
    col = malloc(strlen(format) + 20);
    
    if (NoColor) coll = WHITE;
				
    switch(coll)
    {
		case RED:
			sprintf(col,REDSTR, format);
			break;
		case GREEN:
			sprintf(col,GRNSTR, format);
			break;		
		case YELLOW:
			sprintf(col,YLWSTR, format);
			break;		
		case BLUE:
			sprintf(col,BLUSTR, format);
			break;
		default:
			sprintf(col,"%s",format);
	}

   	va_start (arg, format);
	vfprintf (stdout, col, arg);
	va_end (arg);

	fflush(stdout);

    // release memory
    free(col);
}

/*********************************************************************
** get yes (1) or No (0) 
**********************************************************************/
int yes_or_no(char *mess)
{
	char	answ;
	
	while (1)
	{
		p_printf(YELLOW, mess);
		
		scanf("%c",&answ); 
		
		if (answ == 'n' || answ == 'N') return(0);
		if (answ == 'y' || answ == 'Y') return(1);
	} 
}

/*********************************************************************
** catch signals to close out correctly 
**********************************************************************/
void signal_handler(int sig_num)
{
	switch(sig_num)
	{
		case SIGKILL:
		case SIGABRT:
		case SIGINT:
		case SIGTERM:
			p_printf(YELLOW, "\nStopping gas_sensor reader.\n");
			close_out(2);
			break;
		default:
			p_printf(RED,"\nneglecting signal %d.\n",sig_num);
	}
}
/*********************************************************************
** setup signals 
**********************************************************************/
void set_signals()
{
	struct sigaction act;
	
	memset(&act, 0x0,sizeof(act));
	act.sa_handler = &signal_handler;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGTERM,&act, NULL);
	sigaction(SIGINT,&act, NULL);
	sigaction(SIGABRT,&act, NULL);
	sigaction(SIGSEGV,&act, NULL);
	sigaction(SIGKILL,&act, NULL);
}

/*********************************************************************
** Function name:           usage
** Descriptions:            display usage / command line information
** @param name : name of program
**
**********************************************************************/

void usage(char *name)
{
		p_printf(YELLOW,"%s [-a #] [-f] [-d] [-h] [-v] \n"
		"\nversion 1.0 / September 2017\n"
		"Copyright (c)  2017 Paul van Haastrecht\n"
		"\n"
		"-a #, 	Change I2C address to #.\n"
		"-d, 	Enable debug messages.\n"
		"-c, 	Callibrate under current conditions.\n"
		"-w #, 	Wait time to warm-up ( # minutes).\n"
		"-f, 	Reset to factory defaults.\n"
		"-h,	Show this help text.\n"
		"-n, 	No colored output.\n"
		"\nPower setting\n"
		"-o, 	Turn heating power OFF.\n"
		"-p, 	Turn heating power ON.\n"
		"\nDisplay commands\n"
		"-e, 	Display EEPROM\n"
		"-l #, 	Loop time for reading to # seconds (default %d seconds)\n"
		"-r, 	Get raw data from the sensor.\n"
		"-s #, 	Get sensor values in PPM # times.\n"
		"-S #,	like -s with more details.\n"
		"-A #,	use # as the current I2C address\n"
		"-C #,	use # as correction factor on R0\n"
		"-v, 	Display firmware version.\n\n",
		name, loop_seconds);
}

/*********************************************************************
** Function name:           display_version
** Descriptions:            display Firmware version
**
**********************************************************************/

void display_version()
{
	int ver;

	if ((ver = getVersion()) != -1) 	
		p_printf(YELLOW,"Firmware Version %d\n",ver);
	
	else	close_out(-1);
}
/*********************************************************************
** Function name:           switch_power
** Descriptions:            switch heating power
** @param cmd : 1 = on, 0 = off 
**
* return -1 on error
**********************************************************************/


int switch_power(int cmd)
{
	int i;
	
	// power on
	if (cmd == 1)
	{
		if (powerOn() == 0)
		{
			p_printf(GREEN,"Heating power has been switched ON.\n");
			
			// delay was requested
			if(warm_up_time > 0)
			{
				for (i = warm_up_time ; i != 0 ; i--)
				{
					p_printf(RED,"\rWaiting to warm up for %d minutes   ", warm_up_time);
					sleep(60);
				}
				p_printf(WHITE, "\r                                                  \n");
			}
			return(0);
		}
		
		return(-1);

	}
	else if (powerOff() == 0)
	{
		p_printf(GREEN,"Heating power has been switched OFF.\n");
		return(0);
	}
	return(-1);
}


/*********************************************************************
** Function name:           display_raw
** Descriptions:            display raw data of the sensors
**
**********************************************************************/
	
void display_raw()
{
	float R0_NH3, R0_CO, R0_NO2; 	
	float Rs_NH3, Rs_CO, Rs_NO2; 
	float ratio_NH3, ratio_CO, ratio_NO2; 
	
	// get R0 reference value
	R0_NH3 = getR0(SENSOR_H3);
	R0_CO = getR0(SENSOR_RED);
	R0_NO2 = getR0(SENSOR_OX);
	
	// get current sense value
	Rs_NH3 = getRs(SENSOR_H3);
	Rs_CO = getRs(SENSOR_RED);
	Rs_NO2 = getRs(SENSOR_OX);
	
	ratio_NH3 = Rs_NH3/R0_NH3;
	ratio_CO = Rs_CO/R0_CO;
	ratio_NO2 = Rs_NO2/R0_NO2;
	
	p_printf(GREEN, "Display raw data\n");
	p_printf(YELLOW,"\tNH3 \tCO\tNO2\n");
	p_printf(YELLOW,"R0:\t%3.2f\t%3.2f\t%3.2f\n", R0_NH3, R0_CO, R0_NO2);
	p_printf(YELLOW,"RS:\t%3.2f\t%3.2f\t%3.2f\n", Rs_NH3, Rs_CO, Rs_NO2);
	p_printf(YELLOW,"Ratio:\t%3.2f\t%3.2f\t%3.2f\n", ratio_NH3, ratio_CO, ratio_NO2);
	
}

/**********************************************************************
** Function name:           display_H2
** Descriptions:            display hydrogen
** @param C : hydrogen in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
**
**********************************************************************/

void display_H2(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for Hydrogen\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Hydrogen\n");	
		return;	
	}
	
	// 1ppm = 0,899/22.4
	level = c * 0.004;
	
	p_printf(GREEN, "\nThe concentration of Hydrogen is %3.2f ppm or %3.2f mg/m3\n", c,level);
	
	// if no details requested
	if (! DETAILS) return;
	
	p_printf(YELLOW,"\tThe average hydrogen in dry air is around 5ppm\n");
}


/*******************************************************************
** Function name:           display_CH4
** Descriptions:            display Methane
** @param C : Methane in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
**
*********************************************************************/

void display_CH4(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for Methane\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Methane\n");	
		return;	
	}
	
	// 1ppm = 16.0400/22.4
	level = c * 0.716;
	
	p_printf(GREEN, "\nThe concentration of Methane is %3.2f ppm or %3.2f mg/m3\n", c,level);

	// if no details requested
	if (! DETAILS) return;
	
	p_printf(YELLOW,"\tThe average Methane in dry air is around 20ppm\n");
}


/**********************************************************************
** Function name:           display_NH3
** Descriptions:            display Ammonia
** @param C : Ammonia in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
*  www.engineeringtoolbox.com/ammonia-health-symptoms-d_901.html
**
**********************************************************************/

void display_NH3(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for Ammonia\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Ammonia\n");	
		return;	
	}
	
	// 1ppm = 17.0310/22.4
	level = c * 0.760;
	
	p_printf(GREEN, "\nThe concentration of Ammonia is %3.2f ppm or %3.2f mg/m3\n\t", c,level);
	
	// if no details requested
	if (! DETAILS) return;
	  
	if (c > 500)
		p_printf(RED, "Above 500: Immediate dange to life limit. Leave room and reduce levels.\n");
	else if (c > 400)
		p_printf(RED, "Above 400, below 500: Moderate throat irritation. Damage of mucous membranes with more than 1 hour exposure\n");
	else if (c > 140)
		p_printf(RED, "Above 140, below 400: Moderate eye irritation. No long-term effect in exposures of less than 2 hours\n");
	else if (c > 100)
		p_printf(YELLOW, "Above 100, below 140 : Irritate eyes, throat and mucous membranes. Mild eye, nose, and throat irritation, may\n"
		"develop tolerance in 1 -2 weeks with no adverse effects\n");
	else if (c > 50)
		p_printf(YELLOW, "Around 50. Uncomfortable, breathing support required, Maximum expose limit has been reached. Get out !\n");
	else if (c > 30)
		p_printf(YELLOW, "Around 30. Uncomfortable, breathing support required, Maximum exposure is 15 min\n");
	else if (c > 10)
		p_printf(GREEN, "Around 10. Maybe detectable by smell. If so: don't stay to long\n");
	else
		p_printf(GREEN, "Below 10. Nothing to worry about\n");
}


/*********************************************************************
** Function name:           display_C3H8
** Descriptions:            display Propane
** @param C : Propane in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
**
**********************************************************************/

void display_C3H8(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for C3H8 (Propane)\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for propane\n");	
		return;	
	}
	// 1ppm = 44.09562.0310/22.4
	level = c * 1.969;
	
	p_printf(GREEN, "\nThe concentration of C3H8 (Propane) is %3.2f ppm or %3.2f mg/m3\n", c,level);
	
	// if no details requested
	if (! DETAILS) return;
}

/*********************************************************************
** Function name:           display_C4H10
** Descriptions:            display Iso-Butane
** @param C : Iso-Butane in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
**
**********************************************************************/

void display_C4H10(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for C4H10 (Iso-Butane)\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Iso-Butane\n");	
		return;	
	}
	
	// 1ppm = 58.1222.0310/22.4
	level = c * 2.595;
	
	p_printf(GREEN, "\nThe concentration of C4H10 (Iso-Butane) is %3.2f ppm or %3.2f mg/m3\n", c,level);
	
	// if no details requested
	if (! DETAILS) return;
}

/********************************************************************
** Function name:           display_C2H5
** Descriptions:            display Ethanol
** @param C : Ethanol in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
*********************************************************************/

void display_C2H5(float c)
{
	
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for C2H5OH (Ethanol) \n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Ethanol\n");	
		return;	
	}
	
	// 1ppm = 46.06844/22.4
	level = c * 2.057;
	
	p_printf(GREEN, "\nThe concentration of C2H5OH (Ethanol) is %3.2f ppm or %3.2f mg/m3\n", c,level);

	// if no details requested
	if (! DETAILS) return;
}


/******************************************************************
** Function name:           display_CO
** Descriptions:            display carbon monoxide
** @param C : CO in PPM
* 
*  madur.com/index.php?page=/ppm_mg_m3
*  wwww.carbonmonoxidekills.com/are-you-at-risk/carbon-monoxide-levels/
**
**********************************************************************/

void display_CO(float c)
{
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for CO (Carbon Monoxide)\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Carbon Monoxide\n");	
		return;	
	}
	
	// 1ppm = 28.0100/22.4
	level = c * 1.250;
	
	p_printf(GREEN, "\nThe concentration of CO (Carbon Monoxide) is %3.2f ppm or %3.2f mg/m3\n", c,level);
	
		// if no details requested
	if (! DETAILS) return;
	
	if ( c< 9)
		p_printf(YELLOW, "\t9 ppm is the maximum recommand indoor CO\n");

	else if (c > 9 && c < 25)
		p_printf(YELLOW, "\tBetween 10 and 24 ppm:  possible health effects with long-term exposure\n");

	else if (c > 25)
		p_printf(YELLOW, "\t above 50 ppm : get worried about your health\n");	  
}


/******************************************************************
** Function name:           display_NO2
** Descriptions:            display  Nitrogen Dioxide
** @param C : CO in PPM
**
* madur.com/index.php?page=/ppm_mg_m3
**
*********************************************************************/

void display_NO2(float c)
{
	float level;
	
	if (c < 0)
	{
		p_printf(RED, "\nInvalid concentration for NO2 (Nitrogen Dioxide)\n");	
		return;
	}
	else if (c == 0)
	{
		p_printf(YELLOW, "\nRatio out of range for Nitrogen Dioxide\n");	
		return;	
	}
	
	
	// 1ppm NO2 = * 46 /22.4 mg/m3
	level = c * 2.053571;
	
	p_printf(GREEN, "\nThe concentration of NO2 (Nitrogen Dioxide) is %3.2f ppm or %3.2f mg/m3\n\t", c,level);
	
	// if no details requested
	if (! DETAILS) return;
			
	if ( c < 0.053)
		p_printf(YELLOW, "Below 0.053. This is an acceptable level for one year period.\n");	
	else if ( c < 0.6)
		p_printf(YELLOW, "Below 0.6. This is an acceptable level for one hour period.\n");
	else if ( c < 1.2)
		p_printf(YELLOW, "Below 1.2. This is a dangerous level.\n");
	else if ( c < 1.6)
		p_printf(YELLOW, "Below 1.6. This is a emergency level.\n");
	else
		p_printf(YELLOW,"This is significant harmfull level.\n");

	
}
/********************************************************************
** Function name:           display_senor_value
** Descriptions:            display all possible sensor values
** @param lp : amount of loops to display the sensors
**
*********************************************************************/

void display_sensor_value(int lp)
{
	float c;

	while (lp -- != 0)
	{
		if ((c = calcGas(NH3)) >= 0)	display_NH3(c);
		else
			p_printf(RED, "Invalid concentration for NH3\n");
	
		if ((c = calcGas(CO)) >= 0)		display_CO(c);
		else
			p_printf(RED, "Invalid concentration for CO\n");
	
		if ((c = calcGas(NO2)) >= 0)	display_NO2(c);
		else
			p_printf(RED, "Invalid concentration for NO2\n");
	
		if ((c = calcGas(C3H8)) >= 0)	display_C3H8(c);
		else
			p_printf(RED, "Invalid concentration for C3H8\n");
			
		if ((c = calcGas(C4H10)) >= 0)	display_C4H10(c);
		else
			p_printf(RED, "Invalid concentration for C4H10\n");	
	
		if ((c = calcGas(CH4)) >= 0)	display_CH4(c);
		else
			p_printf(RED, "Invalid concentration for CH4\n");
	
		if ((c = calcGas(H2)) >= 0)		display_H2(c);
		else
			p_printf(RED, "Invalid concentration for H2\n");
	
		if ((c = calcGas(C2H5OH)) >= 0)	display_C2H5(c);
		else
			p_printf(RED, "Invalid concentration for C2H50H\n");
		
		// only if not last
		if (lp > 0)
		{	
			if (DEBUG) p_printf(YELLOW,"wait %d seconds\n", loop_seconds);
		
			sleep(loop_seconds);
		}
	} 
}

/********************************************************************
** Function name:           set_corr_factor
** Descriptions:            set correction factor for R0
** @param cor : number or formula to apply
** 				can be  division : 3.3/5
**				can be multiply  : 5*0.2
**				can be number    : 1.5
** 
**   The VCC can be between 3.3 and 5V, BUT this also determines the ADC steps
**   e.g. 3.3V / 1024 = 3.2mV or 5V / 1024 = 4.8mV per step.
**   
**   This result in different ADC value reading.
**   e.g. assume voltage on ADC pin is 2.5V. 
**   		ADC value will be with 3.3V  2.5 / 3.2mV = 775
**   		ADC value will be with 5V    2.5 / 4.8mV = 512
**    
**   USING FACTORY CALIBRATION VALUES   
**
**   The factory calibration seems to have been done with 3.3V and set 
**   for R0. If the VCC is now 5V the R0 values have to be corrected by: 
**   factory setting *  (3.3 / 5)
**
**	 If VCC is 3.3V, no correction factor has to be provided to the factory 
**   callibration.
**
**   USING LOCAL CALIBRATION VALUES    
** 
**   If local calibration has been done (./gass -c) under the same VCC
**   as the current, then no correction factor have to be provided. However
**   if local calibration was done under a different VCC than the current, 
**   the correction factor has to be provided as well.
**
**
*********************************************************************/


void set_corr_factor(char *cor)
{
	char	*ret;
	double	val1, val2;
	
	// has a formula been provided to devide
	if ((ret = strchr(cor, '/')) != NULL)  
	{
		*ret=0x0;
		val1 = strtod(cor, NULL);
		val2 = strtod(ret+1, NULL);
		
		if (val1 > 0 && val2 > 0)	VCC_correct = val1 / val2;
		else p_printf(RED,"Incorrect formula for correction factor\n");
	}
	// has a formula been provided to multiply
	else if ((ret = strchr(cor, '*'))   != NULL) 
	{
		*ret=0x0;
		val1 = strtod(cor, NULL);
		val2 = strtod(ret+1, NULL);
		
		if (val1 > 0 && val2 > 0)	VCC_correct = val1 * val2;
		else p_printf(RED,"Incorrect formula for correction factor\n");
	}
	else
	{
		VCC_correct = strtod(cor, NULL);

		if (VCC_correct == 0x0) 
		{
			p_printf(RED,"Incorrect number for correction factor\n");
			VCC_correct = 1;
		}
	}

	if (DEBUG) p_printf(YELLOW, "Correction factor set to %2.2f\n",VCC_correct);
}

	
int main(int argc, char *argv[])
{
	int c ;
	int	d_ep = 0, fact = 0, calli = 0, power_on = 0, power_off =0;
	int raw = 0, sens = 0, i2cadd = 0;
	
	if (geteuid() != 0){
        p_printf(RED,"Must be run as root.\n");
        exit(-1);
    }

	// catch signals
	set_signals();

	while (1)
	{
		c = getopt(argc, argv,"-a:cefdvhl:rs:pw:onS:A:C:");

		if (c == -1)	break;
	
		switch (c) {
			case 'd':	// set debug level
				DEBUG = 1;
				break;
			
			case 'e':	// display eeprom
				d_ep = 1;
				break;
			
			case 'c':	// perform callibration
				calli = 1;
				break;
			
			case 'a':	// change i2C address
				i2cadd = (int) strtod(optarg, NULL);
				if (i2cadd > 127 || i2cadd < 0)
				{
					p_printf(RED,"Invalid I2C address. Ignored\n");
					i2cadd = 0;
				}
				break;
			
			case 'f':	// factory setting
				fact=  1;
				break;
			
			case 'v':	// firmware version
				display_version();
				break;
			
			case 'l':	// change loop time
				loop_seconds = (int) strtod(optarg, NULL);
				
				if (loop_seconds > 600)
				{
					p_printf(RED,"Maximum value is 600 seconds. Ignored\n");
					loop_seconds = 5;
				}
				else if (loop_seconds < 2)
				{
					p_printf(RED,"Minimu value is 2 seconds. Ignored\n");
					loop_seconds = 5;
				}
				break;
			
			case 'r':	// raw data
				raw = 1;
				break;
			
			case 'S':	// sensor values with details
				DETAILS = 1;
			case 's':	// sensor value in ppm
				sens = (int) strtod(optarg, NULL);
				break;
			
			case 'p':	// power on heating
				warm_up_time=0;
				power_on = 1;
				break;
			
			case 'o':	// power off heating
				power_off = 1;
				break;
			
			case 'w':	// warmup time in min
				warm_up_time = (int) strtod(optarg, NULL);
				power_on = 1;
				break;
			
			case 'n':	// no color in output
				NoColor=1;
				break;
			
			case 'A':	// set for current I2C address
				use_I2C_add = (int) strtod(optarg, NULL);
				
				if (use_I2C_add > 127 || use_I2C_add < 0)
				{
					p_printf(RED,"Invalid I2C address. Ignored\n");
					use_I2C_add = 0xff;
				}
				
				break;

			case 'C':	// set correction factor
				set_corr_factor(optarg);
				break;			

			case 'h':
			default:	// display help
				usage(argv[0]);
				exit(0);
				break;
		}
	
	}
	// initialize hardware
	if (hw_init() != 0 ) exit(-1);
	
	// call functions
	if (power_off) switch_power(0);
	if (power_on) switch_power(1);
	if (i2cadd) changeI2cAddr(i2cadd);
	if (calli)	doCalibrate();
	if (fact) 	factory_setting();
	if (d_ep) 	display_eeprom();
	if (raw) 	display_raw();
	if (sens) 	display_sensor_value(sens);
		
	close_out(0);
	
	exit(0);
}
