/* header file for Multichannel gas_sensor user program
 * 
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * Initial release September 2017.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */


#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <math.h>
#include <stdarg.h>
#include <bcm2835.h>
#include "gass_lib.h"

/* display color */
#define RED 	1
#define GREEN 	2
#define YELLOW  3
#define BLUE	4
#define WHITE	5

#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"


/******************************************************
 ** supporting routines
 ******************************************************/
// debug details
extern int DEBUG;

/* obtain I2C address to use */
int init_I2c_add();

/* setup hardware  
 * set the BCM2835 for I2c communication 
 * return 0 = ok, -1 = error*/
int hw_init();

/* end the program correctly */
void close_out(int end);

/* Turn power off (cmd = 0) or power on (cmd=1)
 * if requested wait # minnutes for warmup */
int switch_power(int cmd);

/* display message in color
 * @param format : message to display and optional arguments
 *                 same as printf
 * @param color :  RED, GREEN, YELLOW, BLUE, WHITE
 * 
 */
void p_printf (int level, char *format, ...);

/* get yes (1) or No (0) */
int yes_or_no(char *mess);

/* setup signals */
void set_signals();
void signal_handler(int sig_num);

/* set correction factor for R0 */
void set_corr_factor(char *cor);

/******************************************************
 ** display routines
 ******************************************************/
/* display current firmware level */
void display_version();

/* display R0, Rs and ratio in raw format */
void display_raw();

/* display gas information */
void display_sensor_value(int lp);

/* display functions for different gas-types */
void display_C2H5(float c);
void display_C3H8(float c);
void display_C4H10(float c);
void display_CH4(float c);
void display_CO(float c);
void display_H2(float c);
void display_NH3(float c);
void display_NO2(float c);

/* display usage information */
void usage(char *name);

