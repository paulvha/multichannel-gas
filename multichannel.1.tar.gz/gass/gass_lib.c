/* Multi channel gas sensor access library 
 * 
 * Large parts are based on the original library for Arduino 
 * 
 * 
    MutichannelGasSensor.cpp
    2015 Copyright (c) Seeed Technology Inc.  All right reserved.
    Author: Jacky Zhang
    2015-3-17
    http://www.seeed.cc/
    modi by Jack, 2015-8
    The MIT License (MIT)
    Copyright (c) 2015 Seeed Technology Inc.
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
 * 
 * 2017 Paul van Haastrecht <paulvha@hotmail.com>
 * Initial release for Raspberry Pi. September 2017.
 *		WHERE NEEDED THE ORIGINAL LIBRARY WAS CHANGED TO WORK BETTER ON A RASPBERRY PI
 */
 
#include "gass.h"

/** global variables  */

// buf to hold interaction with board
char dta_buf[5];

// current firmware version
int gass_version = 0;

// correction factor on R0
double VCC_correct = 1;

/*********************************************************************************************************
** Function name:           write_gass
** Descriptions:            write to gass sensor the amount of bytes
**
** @param buf : data to be sent
** @param cnt : the amount of characters
** 
** return code
**  0 = OK
** -1 = Error
**********************************************************************************************************/
int write_gass(char *buf, int cnt)
{
	// write
    switch(bcm2835_i2c_write(buf,cnt))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            if(DEBUG) printf(REDSTR,"DEBUG: Write NACK error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_CLKT :
            if(DEBUG) printf(REDSTR,"DEBUG: Write Clock stretch error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_DATA :
            if(DEBUG) printf(REDSTR,"DEBUG: not all data has been written\n");
            return(-1);
            break;
    }

	//give time to settle
	usleep(500);
	
	return (0);
}

/*********************************************************************************************************
** Function name:           read_gass
** Descriptions:            read from gass sensor the amount of bytes
**
** @param buf : store data read
** @param cnt : amount of characters
** 
** return code
**  0 = OK
** -1 = Error
**********************************************************************************************************/
int read_gass(char *buf, int cnt)
{
	switch(bcm2835_i2c_read(buf, cnt))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            if(DEBUG) printf(REDSTR,"DEBUG: Read NACK error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_CLKT :
            if(DEBUG) printf(REDSTR,"DEBUG: Read Clock stretch error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_DATA :
            if(DEBUG) printf(REDSTR,"DEBUG: not all data has been read\n");
            return(-1);
            break;
    }
    
    return(0);
}

/*********************************************************************************************************
** Function name:           get_addr_dta
** Descriptions:            read byte from sensor based on command
**
** @param cmd : command to perform
** @param dta : register to read
** 
** return code
**  0 = OK
** -1 = Error
**********************************************************************************************************/
int get_addr_dta(char cmd, char dta)
{
	char data[2];		// store character write /read
	int r_dta = 0;		// return value
	
	data[0] = cmd;
	data[1] = dta;
	
	// first write request
	if (write_gass(data, 2) < 0)	return(-1);
	
	// perform read answer
	if (read_gass(data, 2) < 0)	return(-1);

	r_dta = data[0];
    r_dta <<= 8;
    r_dta += data[1];

	return(r_dta);
}

/*********************************************************************************************************
** Function name:           get_addr_data_s
** Descriptions:            read single byte from gas sensor register
**
** @param addr_reg : register to read
** 
** return code
**  0 = OK
** -1 = Error
**********************************************************************************************************/
int get_addr_dta_s(char addr_reg)
{
	char r_data [2];
	int	 r_dta;
	
	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
    }	
	
	// first write request
	if (write_gass(&addr_reg, 1) < 0)	return(-1);
	
	// read answer
	if (read_gass(r_data, 2) < 0)	return(-1);

	// compose return 
	r_dta = r_data[0];
    r_dta <<= 8;
    r_dta += r_data[1];

	return(r_dta);
}


/*********************************************************************************************************
** Function name:           getR0
** Descriptions:            get R0 values(obtained in clean air to compare)
**
** @param ch : gas value to get
** 
** return code
** 0 = Error
** 
**********************************************************************************************************/
float getR0(unsigned char ch)
{
    float 	cor;
    
    if(gass_version != 2)
    {
        printf("ERROR: getR0() is NOT support by V1 firmware.\n");
        return 0;
    }
    
    int a = 0;
    
    switch(ch)
    {
        case SENSOR_H3:         // NH3
        a = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_HN3);
        if(DEBUG) printf("R0_NH3 = 0x%x or %d\n",a,a);
        break;
        
        case SENSOR_RED:         // CO or RED
        a = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_CO);
		if(DEBUG) printf("R0_CO = 0x%x or %d\n",a,a);
        break;
        
        case SENSOR_OX:         // NO2 
        a = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_NO2);
        if(DEBUG) printf("R0_NO2 = 0x%x or %d\n",a,a);
        break;
        
        default:;
    }
    
    /* Appling correction factor. 
     * 
     * The VCC can be between 3.3 and 5V, BUT this also determines the ADC steps
     * e.g. 3.3 / 1024 = 3.2mV or 5 / 1024 = 4.8mV per step.
     *  
     * This result in different ADC value reading.
     * e.g. assume voltage on ADC pin is 2.5V. 
     * 		ADC value will be with 3.3V  2.5 / 3.2mV = 775
     * 		ADC value will be with 5V    2.5 / 4.8mV = 512
     * 
     * The factory calibration seems to have been done with 3.3V. 
     * 
     * If the VCC is now 5V the R0 ADC values have to be corrected by: 
     * factory setting *  (3.3 / 5)
     * 
     * This would also be the case if local calibration was done with a
     * different VCC than the current VCC. 
     */
     cor = (float)a * VCC_correct;
     
	/* 
	 * This formula comes from the original Ardnuino Library.
	 * it calculates the sensor resistance in a simplified (but correct) formula
	 * 56 = 56K load resistor serial to sensor
	 */ 

    float r = 56.0 * cor /(1023.0-cor);
	return r;
}


/*********************************************************************************************************
** Function name:           getRs
** Descriptions:            get CURRENT air resistance value 
**
** @param ch : gas to get
** 
** return code
** 0 = Error
** 
**********************************************************************************************************/


float getRs(unsigned char ch)
{
    if(gass_version != 2)
    {
        printf("ERROR: getRs() is NOT support by V1 firmware.\n");
        return -1;
    }
    
    int a = 0;
   
    switch(ch)
    {
        case SENSOR_H3:         // NH3
        a = get_addr_dta_s(CH_VALUE_NH3);
        if (DEBUG) printf("Rs_NH3 = 0x%x or %d\n",a,a);
        break;
        
        case SENSOR_RED:         // CO
        a = get_addr_dta_s(CH_VALUE_CO);
        if(DEBUG) printf("Rs_CO = 0x%x or %d\n",a,a);
        break;
        
        case SENSOR_OX:         // NO2
        a = get_addr_dta_s(CH_VALUE_NO2);
        if(DEBUG) printf("RS_NO2 = 0x%x or %d\n",a,a);
        break;
        
        default:;
    }
    
	/* 
	 * This formula comes from the original Ardnuino Library.
	 * it calculates the sensor resistance in a simplified (but correct) formula
	 * 56 = 56K load resistor serial to sensor  
	 */ 
	 
	float r = 56.0*(float)a/(1023.0-(float)a);
    
	return r;
}

/*********************************************************************************************************
** Function name:           getVersion
** Descriptions:            get the current version firmware on Grove board Multichannel sensor
* 
* return 
* version (2)
* error 0 
*********************************************************************************************************/
int getVersion()
{
    int vers;

    gass_version = 0;
    
    vers = get_addr_dta(CMD_READ_EEPROM, ADDR_IS_SET);
    
    if( vers < 0)
    {
		printf("Error during obtaining version number\n");
		return(-1);
	}

    if (vers == 1126)        // check version 
    {
        gass_version = 2;
        return (2);
    }
    
	printf("The old V1 firmware is not supported by this library\n");
	return(0);
}

/*********************************************************************************************************
** Function name:           powerOff
** Descriptions:            power off sensor heater
** 
** return
**  0 = OK
** -1 = ERROR
*********************************************************************************************************/
int powerOff(void)
{
	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
    }
    
	dta_buf[0] = CMD_CONTROL_PWR;
	dta_buf[1] = 0;
	
	if(write_gass(dta_buf, 2) == -1)
	{
		printf("Could not turn off power\n");
		return(-1);
	}
	
	ledOff();
	return(0);
}

/*********************************************************************************************************
** Function name:           powerOn
** Descriptions:            power on sensor heater
** return
**  0 = OK
** -1 = error
*********************************************************************************************************/
int powerOn(void)
{
	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
    }
    
	dta_buf[0] = CMD_CONTROL_PWR;
	dta_buf[1] = 1;
	if(write_gass(dta_buf, 2) == -1)
	{
		printf("Could not turn on power\n");
		return(-1);
	}
	
	ledOn();
	return(0);
}

/*********************************************************************************************************
** Function name:           readData (OLD ??)
** Descriptions:            read 3 bytes  + CRC from I2C slave
** return
** checksum error -4
** 
*********************************************************************************************************/
int16_t readData(uint8_t cmd)
{
    char buffer[4];
    uint8_t checksum = 0;
    int16_t rtnData = 0;

	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
    }
    
    //send command
    if (write_gass((char *) &cmd, 1) < 0) return(-1);
    
    //get response
	if (read_gass(buffer, 4) != 0) return(-1);

    checksum = (uint8_t)(buffer[0] + buffer[1] + buffer[2]);
    
    if(checksum != buffer[3])
        return -4;		//checksum wrong
    rtnData = ((buffer[1] << 8) + buffer[2]);

    return rtnData;		//successful
}

/*********************************************************************************************************
** Function name:           Led commands
** Descriptions:            Turn led on or OFF
*********************************************************************************************************/
int ledOn()
{
	dta_buf[0] = CMD_CONTROL_LED;
    dta_buf[1] = 1;
    return(write_gass(dta_buf, 2));
}

int ledOff()
{
	dta_buf[0] = CMD_CONTROL_LED;
    dta_buf[1] = 0;
    return(write_gass(dta_buf, 2));
}


/*********************************************************************************************************
** Function name:           calcGas
** Descriptions:            calculate gas concentration of each channel from slave MCU
**                          For explanation of the calculations, see the document in the package
** Parameters:
**                          gas - gas type
** Returns:
**                          float value - concentration of the gas.
**							if 0x0 the ratio or calculated result is out of range
**
** For Ethanol, Hydrogen, Ammonia, propane and ISO-Butane an alternative calculation will be 
** tried if primary choice is not within ratio.
* 
*********************************************************************************************************/
float calcGas(int gas)
{

	float R0_NH3, R0_CO, R0_NO2; 	
	float Rs_NH3, Rs_CO, Rs_NO2; 
	float ratio_NH3, ratio_CO, ratio_NO2; 
    
	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
	}

	// get the ADC reference values (R0)
	R0_NH3 = getR0(SENSOR_H3);
	R0_CO = getR0(SENSOR_RED);
	R0_NO2 = getR0(SENSOR_OX);
	
	// get the current ADC values (Rs)
	Rs_NH3 = getRs(SENSOR_H3);
	Rs_CO = getRs(SENSOR_RED);
	Rs_NO2 = getRs(SENSOR_OX);
	
	ratio_NH3 = Rs_NH3/R0_NH3;
	ratio_CO = Rs_CO/R0_CO;
	ratio_NO2 = Rs_NO2/R0_NO2;

	//printf("ratio_NH3 %f, ratio_CO %f, ratio_NO2 %f\n", ratio_NH3, ratio_CO,ratio_NO2); 
    float c = 0;

    switch(gas)
    {
        case CO:	// Carbon Monoxide
        {
            /* if out of bounds result 0 -- mod by Paul */
            if (ratio_CO > 4  || ratio_CO < 0.01) c=0;
            else
            {
				c = pow(ratio_CO, -1.177)*4.4638;  
				if (c < 1 || c > 1000) c=0;
            }
            break;
        }
        case NO2:	// Nitrogen Dioxide
        {
			/* if out of bounds result 0 -- mod by Paul */
            if (ratio_NO2 > 40  || ratio_NO2 < 0.06) c=0;
            else
            { 
				c = pow(ratio_NO2, 0.9979)*0.1516; 
                if (c < 0.01 || c > 7) c=0;
            }
            break;
        }
        case NH3:	// ammonia
        {
			/* if out of bounds result 0 -- mod by Paul */
            if (ratio_NH3 > 0.9 || ratio_NH3  < 0.05)
            {
				// try the alternative CO sensor
				if (ratio_CO < 1 && ratio_CO > 0.3) 
				{
					c = pow(ratio_CO, -4.33)*0.974;
					if (c < 1 || c > 160) c=0; 
					break;
				}
				c=0;
            }
            else
            { 
				c = pow(ratio_NH3, -1.903)*0.6151; 
                if (c < 1 || c > 160) c=0; 
            }
            break;
        }
        case C3H8:  //propane
        {
            /* if out of bounds result 0 -- mod by Paul */
            if (ratio_NH3 > 0.9 || ratio_NH3  < 0.2) 
            {
				// check for within limits for CO sensor
				if (ratio_CO < 0.18 && ratio_CO > 0.05)
				{
					c = pow(ratio_CO, -1.316)*323.64;
					if (c < 3000 || c > 10500) c=0;
				}
				else
				/* if out of bounds result 0 -- mod by Paul */
					c = 0;
			}
			else
			{
				c = pow(ratio_NH3, -2.492)*569.56;
				if (c < 1000 || c > 30000) c=0;
            }
            break;
        }
        case C4H10:  // iso-butane
        {
            /* check for ratio boundaries-- mod by Paul */
            if (ratio_NH3 > 0.8 || ratio_NH3  < 0.1)
            {
				// check for ratio limits on CO sensor
				if (ratio_CO < 0.07 && ratio_CO > 0.05)
				{
					c = 44680 - (556000 * ratio_CO);
					if (c < 3000 || c > 10500) c=0;
				}
				else
				/* if out of bounds result 0 -- mod by Paul */
					c = 0;
			}
			else
			{
				c = pow(ratio_NH3, -1.888)*503.2;
				if (c < 1000 || c > 30000) c=0;
            }
            break;
        }
        case CH4:  // methane
        {
            /* if out of bounds result 0 -- mod by Paul */
            if (ratio_CO > 0.8 || ratio_CO < 0.45) c=0;
			else
			{
				c = pow(ratio_CO, -4.093)*837.38;
				if (c < 3000 || c > 10500) c=0;
            }
            break;
        }
        case H2:	// hydrogen 
        {
            /* In case the ratio for the primary calculation (CO) is 
             * out of bounds for Hydrogen, try the NH3 sensor
             */
            if (ratio_CO > 1 || ratio_CO < 0.035)
            {
				// check for ratio limits for NH3 sensor
				if (ratio_NH3 < 2 && ratio_NH3 > 0.3)
				{
					c = pow(ratio_NH3, -2.948)*8.0074;
					if (c < 1 || c > 200) c=0;
				}
				else
					/* if out of bounds result 0 -- mod by Paul */
					c = 0;
			}
			else
			{
				c = pow(ratio_CO, -1.781)*0.828;
				if (c < 1 || c > 250) c=0;
            }
            break;
        }
        case C2H5OH:  //Ethanol
        {
            /* In case the ratio for the primary calculation (CO) is 
             * out of bounds for Ethanol, try the NH3 sensor */
      
            if (ratio_CO > 1.05 || ratio_CO < 0.03)
            {
				// check for within limits for NH3 sensor
				if (ratio_NH3 < 0.8 && ratio_NH3 > 0.06)
				{
					c = pow(ratio_NH3, -2.781)*0.2068;
					if (c < 1 || c > 250) c=0;
				}
				else
				/* if out of bounds result 0 -- mod by Paul */
					c = 0;
			}
			else
			{
				c = pow(ratio_CO, -1.58)*1.363;
				if (c < 1.5 || c > 250) c=0;
            }
            break;
        }
        default:
            break;
    }
    
    // checks that the value is a floating point number
    return isnan(c)?-3:c;
}

/*********************************************************************************************************
** Function name:           detect_base_address
** Descriptions:            detect the slave base address
**
** returns:        adress = ok, -1 error
*********************************************************************************************************/
int detect_base_address()
{
	int	i;
	char tmp;
	
	// remember
	int old_debug = DEBUG;
	DEBUG=0;
	
	// loop to find first board
	for (i = 1; i< 127 ; i++)
	{
		// set BCM2835 slaveaddress
		bcm2835_i2c_setSlaveAddress(i);
		
		// if succesfull read
		if (read_gass(&tmp,1) == 0) break;
	}
	
	DEBUG = old_debug;
	
	if ( i < 127) return(i);
	return(-1);
}

/*********************************************************************************************************
** Function name:           changeI2cAddr
** Descriptions:            Change the I2C address
**
** @param newAddr 	new I2C address
** returns:         0 = ok, -1 error
*********************************************************************************************************/
int changeI2cAddr(int newAddr)
{
	dta_buf[0] = CMD_CHANGE_I2C;
	dta_buf[1] = newAddr;
	
	if (write_gass(dta_buf, 2) < 0)	
	{
		printf("could not update to new address %d\n", newAddr);
		return(-1);
	}
	
	/* set NEW slave address for gas sensor*/
	bcm2835_i2c_setSlaveAddress(newAddr);

	// give gassensor processor time to settle
	sleep(1);	
	
	if (detect_base_address() < 0)	
	{
		printf("could not detect sensor on new address\n");
		return(-1);
	}
	
	return(0);
}

/*********************************************************************************************************
** Function name:           factory_setting
** Descriptions:            reset to factory values
**
** returns:         0 = ok, -1 error
*********************************************************************************************************/
int factory_setting()
{
	char	tmp[7];
	int 	i;
	int a0 = 0, a1 = 0, a2 = 0;

	// reset the I2c address (assuming there is only the gas sensor on the cable)	
	if ((i = detect_base_address())> 0)
	{
		printf("Current I2C address is 0x%x\n", i);
		
		if (i != DEFAULT_SLAVE_ADDRESS)
		{
			if(changeI2cAddr(DEFAULT_SLAVE_ADDRESS) == 0) 
			{
				if (getVersion() < 0) return(-1);
				printf("Default slave address 0x%x has been restored\n", DEFAULT_SLAVE_ADDRESS);
			}
			else
			{
				printf("Error during trying to reset I2C to 0x%x\n", DEFAULT_SLAVE_ADDRESS);
				return(-1);
			}
		}
	}
	else
	{
		printf("Could not obtain slave base address\n");
		return(-1);
	}

	// get factory settings
    a0 = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_NH3);
    a1 = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_CO);
    a2 = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_NO2);
    
    if (a0 < 1 || a1 < 1 || a2 < 1)
    {
		printf("Error during reading factory settings\n");
		return(-1);
	}
	
    // overwrite ADC USER setting with factory information
    tmp[0] = CMD_SET_R0_ADC;
    tmp[1] = a0>>8;			
    tmp[2] = a0&0xff;     
    tmp[3] = a1>>8;
    tmp[4] = a1&0xff;

    tmp[5] = a2>>8;
    tmp[6] = a2&0xff;   
    
    if (write_gass(tmp, 7) < 0)	return(-1);

	printf("Factory reference values have been restored\n");
	return(0);
}

/*********************************************************************************************************
** Function name:           display_eeprom
** Descriptions:            reads & display all EEPROM address
**
** returns:         0 = ok, -1 error
*********************************************************************************************************/
int display_eeprom()
{
    int res;
    
    if(gass_version == 1)
    {
        printf("ERROR: display_eeprom() is NOT supported by V1 firmware.\n");
        return(0);
    }
    
    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_IS_SET)) == -1)
	{
		printf("Error during reading eeprom %x\n", res);
		return(-1);
    }
	else
		printf("ADDR_IS_SET =\t\t0x%x\n", res);
		
    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_NH3)) == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
	else
		printf("ADDR_FACTORY_ADC_NH3 = \t0x%x\t(dec) %d\n", res,res);
	

    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_CO)) == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
	else
		printf("ADDR_FACTORY_ADC_CO = \t0x%x\t(dec) %d\n", res,res);

    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_FACTORY_ADC_NO2)) == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
    else
		printf("ADDR_FACTORY_ADC_NO2 = \t0x%x\t(dec) %d\n", res,res);

    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_HN3))  == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
    else
		printf("ADDR_USER_ADC_HN3 = \t0x%x\t(dec) %d\n", res,res);
	
    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_CO))  == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
    else
		printf("ADDR_USER_ADC_CO = \t0x%x\t(dec) %d\n", res,res);

    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_USER_ADC_NO2))  == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
	else
		printf("ADDR_USER_ADC_NO2 = \t0x%x\t(dec) %d\n", res,res);


    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_I2C_ADDRESS))  == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
	else
		printf("ADDR_I2C_ADDRESS = \t0x%x\n", res);

    if ((res = get_addr_dta(CMD_READ_EEPROM, ADDR_IF_CALI))  == -1)
	{
		printf("Error during reading eeprom\n");
		return(-1);
    }
	else
		printf("ADDR_IF_CALI = \t\t0x%x\n", res);

	return(0);
}

/*********************************************************************************************************
** Function name:           doCalibrate
** Descriptions:            tell slave to do a calibration.
                            Assumes that the MICS6814 is in clean air and warmed up 
                            Is already done in the factory...
*********************************************************************************************************/
int doCalibrate(void)
{
	int i, a0, a1, a2, tmp1;
	int cnt ;
    char tmp[7];
    
    int max_delta = 2;		// Maximum delta to original reading
	
	if (gass_version !=  2) 
	{
		printf("Only V2 firmware is supported\n");
		return(-1);
    }

	while(1)
	{
		a0 = get_addr_dta_s(CH_VALUE_NH3);
		a1 = get_addr_dta_s(CH_VALUE_CO);
		a2 = get_addr_dta_s(CH_VALUE_NO2);
		
		printf("Current CH_VALUE_NH3: 0x%x, CH_VALUE_CO: 0x%x, CH_VALUE_NO2: 0x%x\n",a0,a1,a2);
		
		cnt = 0;
		
		// read 20 times the current values
		for(i=0; i<20; i++)
		{
			tmp1 = get_addr_dta_s(CH_VALUE_NH3);
			
			if(a0 - tmp1 > max_delta || tmp1 - a0 > max_delta)
			{
				if (DEBUG) printf("change detected in NH3 value. Was 0x%x, is 0x%x\n",a0,tmp1);
				cnt++;
			}

			tmp1 = get_addr_dta_s(CH_VALUE_CO);
			
			if(a1 - tmp1 > max_delta || tmp1 - a1 > max_delta)
			{
				if (DEBUG) printf("change detected in CO value. Was 0x%x, is 0x%x\n",a1,tmp1);
				cnt++;
			}
			
			tmp1 = get_addr_dta_s(CH_VALUE_NO2);
			
			if(a2 - tmp1 > max_delta || tmp1 - a2 > max_delta)
			{
				if (DEBUG) printf("change detected in NO2 value. Was 0x%x, is 0x%x\n",a2,tmp1);
				cnt++;
			}

			// if more than 5 time difference in original reading
			if (cnt > 5)  break;

			// show progress
			printf(".");
			fflush(stdout);
			
			// wait 1 second
			sleep(1);
		}
		
		printf("\n");  
		
		// if NOT more than 5 times a difference was detected for the last 20 reading/seconds
		if(cnt <= 5) break;
		
		usleep(200);
	}
   
	printf("\nnew CH_VALUE_NH3: 0x%x, CH_VALUE_CO: 0x%x, CH_VALUE_NO2: 0x%x\n",a0,a1,a2);

	// write new USER_ADC setting to the EEPROM
	tmp[0] = CMD_SET_R0_ADC;

	tmp[1] = a0>>8;
	tmp[2] = a0&0xff;
	   
	tmp[3] = a1>>8;
	tmp[4] = a1&0xff;

	tmp[5] = a2>>8;
	tmp[6] = a2&0xff;

	if (write_gass(tmp, 7) < 0)	return(-1);  
    
    return(0);
}
