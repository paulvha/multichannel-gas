/* gas sensor access library 
 * 
 * Large parts are based on the original library for Arduino 
 * 
 * 
    MutichannelGasSensor.cpp
    2015 Copyright (c) Seeed Technology Inc.  All right reserved.
    Author: Jacky Zhang
    2015-3-17
    http://www.seeed.cc/
    modi by Jack, 2015-8
    The MIT License (MIT)
    Copyright (c) 2015 Seeed Technology Inc.
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
 * 
 * 2017 Paul van Haastrecht <paulvha@hotmail.com>
 * Initial release for Raspberry Pi. September 2017.
 *		WHERE NEEDED THE ORIGINAL LIBRARY WAS CHANGED TO WORK BETTER ON A RASPBERRY PI
 */

/* needed for R0 factory correction factor */
double VCC_correct;

// define addresses and actions
#define ADDR_IS_SET             0           // indicates firmware version
#define ADDR_FACTORY_ADC_NH3    2			// factory calibration setting for the ADC
#define ADDR_FACTORY_ADC_CO     4
#define ADDR_FACTORY_ADC_NO2    6

#define ADDR_USER_ADC_HN3       8			// current R0 to use (either factory or calibrated)
#define ADDR_USER_ADC_CO        10
#define ADDR_USER_ADC_NO2       12
#define ADDR_IF_CALI            14          // IF USER HAD CALI ??

#define ADDR_I2C_ADDRESS        20			// get I2C address (WHY you know that !!)

#define CH_VALUE_NH3            1			// current Rs ADC value
#define CH_VALUE_CO             2
#define CH_VALUE_NO2            3

/** commands to use */
#define CMD_ADC_RES0            1           // NH3
#define CMD_ADC_RES1            2           // CO
#define CMD_ADC_RES2            3           // NO2
#define CMD_ADC_RESALL          4           // ALL CHANNEL ????
#define CMD_CHANGE_I2C          5           // CHANGE I2C
#define CMD_READ_EEPROM         6           // READ EEPROM VALUE, RETURN UNSIGNED INT
#define CMD_SET_R0_ADC          7           // SET user R0 ADC VALUE
#define CMD_GET_R0_ADC          8           // GET user R0 ADC VALUE
#define CMD_GET_R0_ADC_FACTORY  9           // GET FACTORY R0 ADC VALUE
#define CMD_CONTROL_LED         10			// led on or off
#define CMD_CONTROL_PWR         11			// switch 3.3V heating /reference voltage

#define	SENSOR_H3	0
#define	SENSOR_RED 	1
#define	SENSOR_OX 	2

/* default I2C address */
#define DEFAULT_SLAVE_ADDRESS 4

enum{CO, NO2, NH3, C3H8, C4H10, CH4, H2, C2H5OH};

/********************************************************************
** All functions in gass_lib.c
*********************************************************************/

/* return the resistance value for the USER_ADC value for sensor*/
float getR0(unsigned char ch);

/* return the resistance value for the current ADC value for sensor*/
float getRs(unsigned char ch);

/* calculate the current PPM for a specific gas */
float calcGas(int gas);

/* read the amount of bytes from board */
int read_gass(char *buf, int cnt);

/* write the amount of bytes to board */
int write_gass(char *buf, int cnt);

/* read byte from sensor based on command */
int get_addr_dta(char cmd, char dta);

/* read byte from register */
int get_addr_dta_s(char addr_reg);

/* get current version of firmware of the gas sensor */
int getVersion();

/* change the I2C address */
int changeI2cAddr(int newAddr);

/* detect the current I2C address */
int detect_base_address();

/* display the Grove board EEPROM values */
int display_eeprom();

/* Handle heating power */
int powerOff(void);
int powerOn(void);

/* handle led */
int ledOn();
int ledOff();

/* overwrite the USER_ADC with the FACTORY ADC values */
int factory_setting();

/* perform callibration in current air
 * store the values USER_ADC in the EEPROM */
int doCalibrate(void);
