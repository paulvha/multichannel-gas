# make gassensor
# Initial release September 2017 , Paul van Haastrecht.
gcc -Wall -o gass gass.c gass_lib.c -l bcm2835 -lm
